package cs241e.assignments

object A9 {
  /*
  Write a WLPP program that takes two parameters, x and y, and returns the greatest common divisor gcd(x,y). You may assume that 0 < x,y < 231. Hint: http://www.google.ca/search?q=euclidean+algorithm */

}
